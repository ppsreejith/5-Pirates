<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Untitled Document</title>

<script type="text/javascript">
function showDiv1(topMenu) {
var a = document.getElementById('instructions');
var b = document.getElementById('aboutgame');
var c = document.getElementById('howtoplay');

var d = document.getElementById('instructions1');
var e = document.getElementById('aboutgame1');
var f = document.getElementById('howtoplay1');
a.style.display = "block";
b.style.display = "none";
c.style.display = "none";
d.style.display = "block";
e.style.display = "none";
f.style.display = "none";
}

function showDiv2(topMenu) {
var a = document.getElementById('instructions');
var b = document.getElementById('aboutgame');
var c = document.getElementById('howtoplay');
var d = document.getElementById('instructions1');
var e = document.getElementById('aboutgame1');
var f = document.getElementById('howtoplay1');
a.style.display = "none";
b.style.display = "block";
c.style.display = "none";
d.style.display = "none";
e.style.display = "block";
f.style.display = "none";
}

function showDiv3(topMenu) {
var a = document.getElementById('instructions');
var b = document.getElementById('aboutgame');
var c = document.getElementById('howtoplay');
var d = document.getElementById('instructions1');
var e = document.getElementById('aboutgame1');
var f = document.getElementById('howtoplay1');
a.style.display = "none";
b.style.display = "none";
c.style.display = "block";
d.style.display = "none";
e.style.display = "none";
f.style.display = "block";

}
</script>
</head>

<body background="images/backg.jpg">

<div class="rule" style="width:400px; height:650px; float:left;">
<a href="#" onClick="showDiv1('instructions'); return false;"> <img src="images/instruct.jpg" width="350px;" height="60px;" /> </a>
<br />
<a href="#" onClick="showDiv2('aboutgame'); return false;"> <img src="images/story.jpg" width="350px;" height="60px;" /> </a>
<br />
<a href="#" onClick="showDiv3('howtoplay'); return false;"> <img src="images/howtoplay.jpg" width="350px;" height="60px;" /> </a>
</div>

<div class="rulestext" style="width:700px; height:650px; float:left;">

<div id="instructions"  style="display:none;">
<b style="font-size:36px;">INSTRUCTIONS</b>
<br />
<br />
1. This is a game of strategy that is based on direct competition between individual players. All your opponents are human users.
<br /><br />
2. Sessions start from 26th October 12noon and go on till 30th October night. There shall be 2 sessions per day. 
<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;a) Morning session:  8 am to 6 pm
<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;b) Night session: 9pm to 1 am
<br />
All are requested to follow us on the facebook page to stay updated.
<br /><br />
3. Session on 26th October morning,  is a Practice session. Player’s scores in this session will have not be added to their tally. However they are encouraged to read all the rules and instructions. Competition begins on 26th October evening session,i.e from 9pm to 1 am. Any moves made beyond the closing time of session will not be valid.
<br /><br />
4. New bonuses, penalties will be introduced every now and then. Information on the same can be found on Dash board. 
<br /><br />
5. You can register anytime before 8 pm on 30th October. It is mandatory to register at least 1 hour before a session. You can register during a session also, but start playing only after the next session begins.
<br /><br />
6. If a player does turn up to play in a session, his move is substituted by the computer’s intelligent move. Thus none of his/her opponents will be affected in any way and theydon’t need to change strategies. However the absentee player will get no score for the game’s result.
<br /><br />
7. This being a game where your opponent makes his move keeping your strategy in mind, and your move plays a key role in determining your opponent’s results, a player who misses 3 sessions in a row will be temporarily removed. You will have to reregister if you wish to start playing. On re-registering you previous score will be given back to you.
<br /><br />
8. Top 3 individual winners will get cash prizes worth Rs. 6000. Non IIT Kharagpur participants are not entitled to prize money.
<br /><br />
9. There will be a special prize for best performing hostel wing. For this scores of top 10 performers from each wing will be added.
<br /><br />
10. Fake accounts are strictly prohibited and will be deleted.
<br /><br />
11. The KGPian Game Theory Society reserved rights to make any changes to the above mentioned clauses, and in any matters of conflict decision of the society will be final. 

</div>


<div id="aboutgame"  style="display:none;" >
<b style="font-size:36px;">The Story So Far</b>
<br />
<br />
Welcome to Brethren of the Coast- a unique game of strategy by the KGPian Game Theory Society. Inspired by the famous 5-pirates game but with a twist, Brethren of the Coast is a fitting test to your strategic thinking skills where you battle your wits against every other player on the net. The game revolves around pirates in 5 famous pirate ships namely:
<br  />
<br  />
a) Queen Anne’s Revenge (Ship 1)
<br />
b) Caroline (Ship 2)
<br />
c) Whydah Gally (Ship 3)
<br />
d) Adventure Galley (Ship 4)
<br />
e) Royal Revenge (Ship 5)
<br />
<br />
<b>The story:</b>
<br />
<br />
A crew of fierce pirates on Queen Anne’s Revenge has just looted a Spanish ship passing through the Pacific. Among the valuables they have looted is a chest filled with 100 gold coins. There are 5 of these pirates on the ship and they need to divide the gold amongst themselves.  The pirates have a strict order of seniority as follows:
<br />
<br />
a) The Captain               (Player 1)
<br />
b) The Quarter Master        (Player 2)
<br />
c) The Boatswain	         (Player 3)
<br />
d) The Sailing Master        (Player 4)
<br />
e) The Navigator	         (Player 5)
<br />
<br />The pirate world's rules of distribution are thus: that the most senior pirate (player 1)should propose a distribution of the 100 coins among all 5. The pirates, including the proposer, then vote on whether to accept this distribution. If the proposed allocation is approved by >= 50% crew including the proposer, it happens. If not, the proposer is thrown overboard from the pirate ship and dies and the next in command makes his proposed distribution. This happens till a proposal has been accepted or only 2 pirates remain and player 4’s proposal is final.

<br />
<br />
As luck would have it, the other 4 pirate crews too looted Spanish ships and they also face the same task of dividing the 100 gold coins. Your objective as a free pirate is to visit all 5 ships and maximise your gold. In each ship you play against 4 different pirates, and at a different position of seniority as explained in the rules.

</div>

<div id="howtoplay"  style="display:none;">
<b style="font-size:36px">
How to play</b>
<br />
<br /><b>
First read ‘The Story So Far’ section
</b>
<br />
<br />
<br />
1. The players are divided into groups of 5, each player being a part of 5 such groups at different positions of hierarchy.  All groups are similar in terms of relative difference and level of players. Thus each player plays against 20 unique players every session.
<br /><br />
2. Players will not be able to see their opponent’s name or identity.
 <br />
<br />
3. For each ship you occupy the following position of seniority:
<br /><br />
a) Ship 1- 1st in command
<br />
b) Ship 2- 2nd in command
<br />
c) Ship 3- 3rd in command
<br />
d) Ship 4- 4th in command
<br />
e) Ship 5- Lowest in seniority.
<br />
Your total earnings for the session is sum of your earnings from each ship.
<br />
<br />

4. Consider ship 1: As the senior most pirate (Player 1) you must make a distribution of coins that you think will be accepted by at least 2 more people excluding yourself and is most profitable for you. Your co-pirates are real human players. As you enter your distribution, they enter a value that tells their minimum expectation from you. At end of session, your proposal to each player is matched against his/her minimum expectation. If your proposal is greater than or equal to the minimum expectation of that player, the proposal is deemed to be accepted by him/her, else it is deemed rejected. You cannot see any other player’s expectation from you and they cannot see your proposal. What you can see however is every player’s history of moves to guess his/her strategy. Confusing? Let’s see through an example: 
 Let us say your proposed distributions and your opponent’s expectations are as follows: 
 
 <br />
 <img src="images/analysis table.png" width="544" height="319" />
 <br />

As can be seen from the table, players 2 and 5 reject your proposal. Players 3 and 4 accept it. Thus the proposal stands as not more than 50% reject it. The final scores for all players on this ship are:
Player 1: 40, Player 2: 15, Player 3: 15, Player 4: 15, Player 5: 15
<br />
<br />

Now what is player 3 had demanded 30 as the minimum? Then your proposal would have failed due to rejection by majority. You would have got 0 and the rest 4 would receive scores based on Player 2’s proposed distribution. 

<br />
<br />

5. On ship 2, you are the 2ndin seniority (Player 2). Note that now you play against a different set of 4 people. So the players 3,4, 5 are not same as on ship 1. You will now enter the following data:
<br />
a) Minimum expectation from Player 1
<br />
b) If player 1 dies what is your proposed distribution to 
<br />
Player 2 (you)?
<br />
Player 3
<br />
Player 4
<br />
Player 5
<br />
<br />
c) Comparisons similar to those discussed in point 2 take place. If player 1 on this ship lives, you get a score based on his/her distribution. Only if he/she dies, your proposal is made. If more than 2 players reject your proposal then you too die, else your proposal stands and decides the final distribution.
<br />
<br />

6. On ship 3, you are 3rd in seniority against 4 new players.  You enter the following data:
<br />
a) Minimum expectation from Player 1
<br />
b) Minimum expectation from player 2
<br />
c) If player 1 dies AND player 2 dies what is your proposed distribution to 
<br />
Player 3 (you)
<br />
Player 4
<br />
Player 5
<br />
<br />
d) Comparisons similar to those discussed in point 2 take place. If player 1 or 2 on this ship lives, you get a score based on 1’s/2’s distribution. Only if they both die, your proposal is made. If more than 1 player (majority) reject your proposal then you too die, else your proposal stands and decides the final distribution.
<br />

<br />
7. Similar choices are made in Ship 4 and 5 as player 4 and 5 respectively. 
<br />
<br />
8. On each ship your objective is to get as many coins as you think are ‘possible’.  For e.g. as player 1 you may be tempted to keep all coins to yourself but you stand the risk of being killed and getting nothing! Similary be careful when demanding too much! Say as player 3 you demand too much from Player 1 and 2 to get them killed so that you can make the proposal. It may so happen that Player 1 who made you a decent offer was rejected by the majority including you and player 2 got away by giving you much less that player 1’s offer by pleasing one or more of player 4 and 5 ! So plan your move carefully. 
<br />
<br />
9. To help you make the right decision, we shall show you every opponent’s skill level and his/her history of moves upto the nth session (n being the session number). Skill level is marked by number of stars above the players head. 3 stars indicate a player in top 33%  on rankings table, 1 start indicates the bottom 33% and 2 stars indicate those in middle. Clicking on a player will show you his/her history. For example, let’s say  in session 4, on ship 1, by clicking on player 3 you see this. (You are player 1)
<br />
<img src="images/tablehistory.png" width="600" height="220" />
<br />
From above table you can see that in session 1 player 2 demanded 20 from player 1 and got 25. This prompted him to demand 25 in session 2. But the new player 1 had offered less (and subsequently he was killed). Now Player 2 gave 0 to player 3 and still got away! So 3 who could have got something +ve from player one ends up with nothing. Something similar happened in session 3.
<br />
<br />
Now you as player 1 can think, what has player 3 learnt from the game. Will he still demand a sum of 20? He must have realised that most player 2s offer him nothing; he may reduce his demand from 1 to get something at least? But at same time, what if Player 3 has still not learnt his lesson? Should you offer more or less?
<br />
<br />

You can see similar data about each player. This information will help you make your move against all kinds of opponents. You must identify which player’s survival is good for you and who you must please. There’s no need to make all players happy!
<br />
<br />

In session 1 of course you will not have this assistance.  

<br /><br />
10. Every alternate session the amount of gold in the booty will double. Also, with every new session, new bonuses and penalties will be added to the game! Don’t forget to cash on these. 
</div>

</div>
<div class="imagerules"  style="width:100px; height:650px; float:left;">

<div id="instructions1" style="position:fixed; display:none;">
<img src="images/instructions.png" />
</div>
<div id="aboutgame1" style=" position:fixed; display:none;">
<img src="images/storysofar.png" />
</div>
<div id="howtoplay1" style="position:fixed; display:none;">
<img src="images/howtoplay.png" />
</div>
</div>
</body>
</html>