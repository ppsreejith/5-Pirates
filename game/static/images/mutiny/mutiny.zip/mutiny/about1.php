<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>

<link rel="stylesheet" type="text/css" href="co.css" />
<link rel="stylesheet" type="text/css" href="a.css" />
<link rel="stylesheet" type="text/css" href="cs.css" />
</head>

<body class="about1">


<div id="content" class="next"  style="height:665px;width:90px;float:left;">
<br /> <br /><br /><br /><br /><br />
<br />
<br /><br /><br /><br /><br /><br /><br /><br />
<br />
<br /><br /><br /><br /><br /><br /><br /><br /><br />

&nbsp;&nbsp;&nbsp;<a class="button_example" href="about.php" target="main">  Prev  </a></div>

<div id="menu" style="height:665px;width:875px;float:left;">
<b>Menu</b><br>
HTML<br>
CSS<br>
JavaScript</div>

<div id="content" class="next"  style="height:665px;width:90px;float:left;">
<br /> <br /><br /><br /><br /><br />
<br />
<br /><br />
<br />
<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />

&nbsp;&nbsp;&nbsp;&nbsp;<a class="button_example" href="about2.php" target="main">  Next  </a><br />
<br />
&nbsp;&nbsp;&nbsp;&nbsp;<a class="button_example" href="game.php" target="main">    Skip    </a></div>

</body>
</html>