<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
  <img src="images/map.jpg" alt="Player" usemap="#gameplay" />
  <map name="gameplay">
    
    <area shape="rect" coords="65,324,130,475" href="play2.php" title="play2" alt="Youtube" target="main" />
    <area shape="rect" coords="265,320,345,475" href="play3.php" title="play3" alt="Youtube" target="main" />
    <area shape="rect" coords="480,260,565,490" href="play1.php" title="play1" alt="Youtube" target="main" />
    <area shape="rect" coords="730,320,800,480" href="play4.php" title="play4" alt="Youtube" target="main" />
    <area shape="rect" coords="920,320,980,480" href="play5.php" title="play5" alt="Youtube" target="main" />  
</map>
</body>
</html>