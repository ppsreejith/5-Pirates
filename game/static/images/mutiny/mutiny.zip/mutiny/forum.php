<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link rel="stylesheet" type="text/css" href="co.css" />
<link rel="stylesheet" type="text/css" href="a.css" />
<link rel="stylesheet" type="text/css" href="cs.css" />
</head>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="home.php" target="_parent" title="Home"><img src="images/home.jpg" style="width:100px; height:100px;" /></a>
<div id="fb-root"></div>
<script>
(function(d, s, id) 
{
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<table><tr><td align="left">
<div style="margin: 10px -11px" align="left">
		<fb:like-box href="https://www.facebook.com/The.KGTS" width="250" height="190" show_faces="true" header="false" border_color="#FFF" stream="false"></fb:like-box>
	</div></td></tr></table>
<style>
p
{
	font-weight:bold;
}
</style>
<body bgcolor="#000000">
   <a class="button_example" target="main" href="about.php">ABOUT THE GAME</a><br/><br/>
   <a class="button_example" target="main" href="rules.php">RULES</a><br/><br/>
   	<a class="button_example" target="main" href="leaderboard.php">LEADERBOARD</a>
    
</body>
</html>